/*
SQLyog Enterprise - MySQL GUI v6.56
MySQL - 5.5.27 : Database - role_based
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`role_based` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `role_based`;

/*Table structure for table `account` */

DROP TABLE IF EXISTS `account`;

CREATE TABLE `account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` varchar(100) DEFAULT NULL,
  `bank` varchar(100) DEFAULT NULL,
  `aadhar` varchar(100) DEFAULT NULL,
  `pan` varchar(100) DEFAULT NULL,
  `acc_no` varchar(100) DEFAULT NULL,
  `ifsc` varchar(1000) DEFAULT NULL,
  `cardno` varchar(100) DEFAULT NULL,
  `cvv` varchar(100) DEFAULT NULL,
  `created_date` varchar(100) DEFAULT NULL,
  `exp_date` varchar(100) DEFAULT NULL,
  `amount` varchar(100) DEFAULT NULL,
  `req_amount` varchar(100) DEFAULT NULL,
  `dep_status` varchar(100) DEFAULT NULL,
  `with_req_amount` varchar(100) DEFAULT NULL,
  `with_status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `account` */

insert  into `account`(`id`,`cid`,`bank`,`aadhar`,`pan`,`acc_no`,`ifsc`,`cardno`,`cvv`,`created_date`,`exp_date`,`amount`,`req_amount`,`dep_status`,`with_req_amount`,`with_status`) values (3,'2','SBI','123456789876','CNKPG0708N','24562174327','SBIN0001','2961212592921517','159','2025-02-05 15:50:51','2030-02-05','0','0','waiting','0','waiting');

/*Table structure for table `bank` */

DROP TABLE IF EXISTS `bank`;

CREATE TABLE `bank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank` varchar(1000) DEFAULT NULL,
  `ifsc` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `bank` */

insert  into `bank`(`id`,`bank`,`ifsc`) values (4,'SBI','SBIN0001'),(5,'ICICI','ICICI0002');

/*Table structure for table `customer` */

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank` varchar(1000) DEFAULT NULL,
  `name` varchar(1000) DEFAULT NULL,
  `email` varchar(1000) DEFAULT NULL,
  `mobile` varchar(1000) DEFAULT NULL,
  `address` varchar(1000) DEFAULT NULL,
  `username` varchar(1000) DEFAULT NULL,
  `password` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `customer` */

insert  into `customer`(`id`,`bank`,`name`,`email`,`mobile`,`address`,`username`,`password`) values (2,'SBI','gkv','gkvtechsolutions@gmail.com','9640257290','hyderabad','gkv','123');

/*Table structure for table `employee` */

DROP TABLE IF EXISTS `employee`;

CREATE TABLE `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(1000) DEFAULT NULL,
  `mobile` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `username` varchar(1000) DEFAULT NULL,
  `password` varchar(1000) DEFAULT NULL,
  `status` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `employee` */

insert  into `employee`(`id`,`bank`,`name`,`email`,`mobile`,`address`,`username`,`password`,`status`) values (5,'SBI','kishan','kishan@gmail.com','9640257292','hyderabad','kishan','123','Cashier'),(6,'SBI','streamway','streamwaytechnologiespvtltd@gmail.com','9493040484','hyderabad','streamway','123','Manager'),(7,'SBI','venkat','venkat@gmail.com','9640257290','hyderabad','venkat','123','Employee');

/*Table structure for table `transactions` */

DROP TABLE IF EXISTS `transactions`;

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` varchar(100) DEFAULT NULL,
  `bank` varchar(1000) DEFAULT NULL,
  `account` varchar(1000) DEFAULT NULL,
  `status` varchar(1000) DEFAULT NULL,
  `amount` varchar(1000) DEFAULT NULL,
  `date` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `transactions` */

insert  into `transactions`(`id`,`cid`,`bank`,`account`,`status`,`amount`,`date`) values (3,'2','SBI','82478582222','deposit','200000','2025-02-05 15:53:38'),(4,'2','SBI','82478582222','withdraw','14500','2025-02-05 15:55:05');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
