from django.urls import path,include
from BankingApp import views


urlpatterns = [
    path('login', views.login),
    path('BankRegister', views.BankRegister),
    path('RegAction', views.RegAction),
    path('LogAction', views.LogAction),
    path('emphome', views.emphome),
    path('ViewAccRequest', views.ViewAccRequest),
    path('GenerateAcc', views.GenerateAcc),
    path('GenerateCNo', views.GenerateCNo),
    path('GenerateCVV', views.GenerateCVV),
    path('cashhome', views.cashhome),
    path('CaDepositRequest', views.CaDepositRequest),
    path('AcceptDeposit', views.AcceptDeposit),
    path('CaWithdrawRequest', views.CaWithdrawRequest),
    path('AcceptWithdraw', views.AcceptWithdraw),
    path('manhome', views.manhome),
    path('MViewEmployees', views.MViewEmployees),
    path('MViewAccRequest', views.MViewAccRequest),
    path('MViewAllTransactions', views.MViewAllTransactions),

]
