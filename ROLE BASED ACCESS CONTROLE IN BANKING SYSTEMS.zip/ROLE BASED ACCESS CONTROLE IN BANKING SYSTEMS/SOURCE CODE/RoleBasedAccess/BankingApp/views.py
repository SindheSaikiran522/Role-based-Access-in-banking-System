from django.shortcuts import render
import Database
import random
from datetime import datetime, timedelta


# Create your views here.
def login(request):
    con = Database.connect()
    cur = con.cursor()
    cur.execute("select * from bank")
    data = cur.fetchall()
    output = ""
    for d in data:
        output += f"<option value={d[1]}>{d[1]}</option>"
    output += ""

    context = {'data': output}
    return render(request, 'BankingApp/Login.html', context)

def BankRegister(request):
    con=Database.connect()
    cur=con.cursor()
    cur.execute("select * from bank")
    data=cur.fetchall()
    output=""
    for d in data:
        output+=f"<option value={d[1]}>{d[1]}</option>"
    output+=""

    context={'data':output}
    return render(request,'BankingApp/Register.html',context)

def RegAction(request):
    if request.method=='POST':
        bank = request.POST['bank']
        name = request.POST['name']
        email = request.POST['email']
        mobile = request.POST['mobile']
        address = request.POST['address']
        uname = request.POST['username']
        pwd = request.POST['password']

        con = Database.connect()
        cur = con.cursor()
        cur.execute("select * from employee where email='"+email+"' or mobile='"+mobile+"'")
        data=cur.fetchone()
        if data is not None:
            cur.execute("select * from bank")
            data = cur.fetchall()
            output = ""
            for d in data:
                output += f"<option value={d[1]}>{d[1]}</option>"
            output += ""

            context = {'msg': "Email or Mobile Number is Already Exist...!!",'data': output}
            return render(request, 'BankingApp/Register.html', context)
        else:
            cur.execute("insert into employee values(null,'"+bank+"','"+name+"','"+email+"','"+mobile+"','"+address+"','"+uname+"','"+pwd+"','waiting')")
            con.commit()
            cur.execute("select * from bank")
            data = cur.fetchall()
            output = ""
            for d in data:
                output += f"<option value={d[1]}>{d[1]}</option>"
            output += ""

            context = {'msg': "Registration Successful...!!",'data': output}
            return render(request, 'BankingApp/Register.html', context)

def LogAction(request):
    bank = request.POST['bank']
    uname = request.POST['username']
    pwd = request.POST['password']

    con = Database.connect()
    cur = con.cursor()
    cur.execute("select * from employee where username='" + uname + "' and password='" + pwd + "' and bank='"+bank+"'")
    d=cur.fetchone()
    if d is not None:
        status=d[8]
        if status !='waiting':
            role=d[8]
            if role=='Manager':
                request.session['role']=d[8]
                request.session['id']= d[0]
                request.session['bank'] = d[1]
                request.session['name'] = d[2]
                request.session['email'] = d[3]
                request.session['mobile'] = d[4]
                return render(request,'BankingApp/ManagerHome.html')
            elif role=='Cashier':
                request.session['role'] = d[8]
                request.session['id'] = d[0]
                request.session['bank'] = d[1]
                request.session['name'] = d[2]
                request.session['email'] = d[3]
                request.session['mobile'] = d[4]
                return render(request, 'BankingApp/CashierHome.html')
            else:
                request.session['role'] = d[8]
                request.session['id'] = d[0]
                request.session['bank'] = d[1]
                request.session['name'] = d[2]
                request.session['email'] = d[3]
                request.session['mobile'] = d[4]
                return render(request, 'BankingApp/EmployeeHome.html')
        else:
            cur = con.cursor()
            cur.execute("select * from bank")
            data = cur.fetchall()
            output = ""
            for d in data:
                output += f"<option value={d[1]}>{d[1]}</option>"
            output += ""

            context = {'data': output, 'msg': 'Login Failed Due to Role is Not Assied By Admin...!!'}
            return render(request, 'BankingApp/Login.html', context)

    else:
        cur = con.cursor()
        cur.execute("select * from bank")
        data = cur.fetchall()
        output = ""
        for d in data:
            output += f"<option value={d[1]}>{d[1]}</option>"
        output += ""

        context = {'data': output,'msg':'Login Failed...!!'}
        return render(request, 'BankingApp/Login.html', context)

def emphome(request):
    return render(request, 'BankingApp/EmployeeHome.html')
def getTableData(bank):
    table = "<table><tr>"
    table += "<th>Requested Date</th>"
    table += "<th>Customer ID</th>"
    table += "<th>Aadhar No</th>"
    table += "<th>Pan No</th>"
    table += "<th>Account No</th>"
    table += "<th>IFSC code</th>"
    table += "<th>Card No</th>"
    table += "<th>CVV</th>"
    table += "<th>Expiry Date</th>"
    table += "</tr>"

    con = Database.connect()
    cur = con.cursor()
    cur.execute("select * from account where bank='" + bank + "'")
    data = cur.fetchall()
    for d in data:
        acc = d[5]
        cno = d[7]
        cvv = d[8]
        if acc == 'waiting':
            table += "<tr>"
            table += f"<td>{d[9]}</td>"
            table += f"<td>{d[1]}</td>"
            table += f"<td>{d[3]}</td>"
            table += f"<td>{d[4]}</td>"
            table += f"<td><a href='GenerateAcc?id={d[0]}'>Generate Acc No</a></td>"
            table += f"<td>{d[6]}</td>"
            table += f"<td><a href='GenerateCNo?id={d[0]}'>Generate Card No</a></td>"
            table += f"<td><a href='GenerateCVV?id={d[0]}'>Generate Card Cvv</a></td>"
            table += f"<td>{d[10]}</td>"
            table += "</tr>"
        elif cno=='waiting' and acc !='waiting':
            table += "<tr>"
            table += f"<td>{d[9]}</td>"
            table += f"<td>{d[1]}</td>"
            table += f"<td>{d[3]}</td>"
            table += f"<td>{d[4]}</td>"
            table += f"<td>{d[5]}</td>"
            table += f"<td>{d[6]}</td>"
            table += f"<td><a href='GenerateCNo?id={d[0]}'>Generate Card No</a></td>"
            table += f"<td><a href='GenerateCVV?id={d[0]}'>Generate Card Cvv</a></td>"
            table += f"<td>{d[10]}</td>"
            table += "</tr>"
        elif cvv =='waiting' and acc!='waiting' and cno!='waiting':
            table += "<tr>"
            table += f"<td>{d[9]}</td>"
            table += f"<td>{d[1]}</td>"
            table += f"<td>{d[3]}</td>"
            table += f"<td>{d[4]}</td>"
            table += f"<td>{d[5]}</td>"
            table += f"<td>{d[6]}</td>"
            table += f"<td>{d[7]}</td>"
            table += f"<td><a href='GenerateCVV?id={d[0]}'>Generate Card Cvv</a></td>"
            table += f"<td>{d[10]}</td>"
            table += "</tr>"
        else:
            table += "<tr>"
            table += f"<td>{d[9]}</td>"
            table += f"<td>{d[1]}</td>"
            table += f"<td>{d[3]}</td>"
            table += f"<td>{d[4]}</td>"
            table += f"<td>{d[5]}</td>"
            table += f"<td>{d[6]}</td>"
            table += f"<td>{d[7]}</td>"
            table += f"<td>{d[8]}</td>"
            table += f"<td>{d[10]}</td>"
            table += "</tr>"

    table += "</table>"
    return table


def ViewAccRequest(request):
    bank=request.session['bank']

    table = getTableData(bank)
    context = {'data': table}
    return render(request, 'BankingApp/ViewAccRequest.html', context)

def GenerateAcc(request):
    bank = request.session['bank']
    rid=str(request.GET['id'])
    account_number = ''.join(str(random.randint(1, 9)) for _ in range(11))
    con=Database.connect()
    cur=con.cursor()
    cur.execute("update account set acc_no='"+str(account_number)+"'where id='"+rid+"'")
    con.commit()
    table = getTableData(bank)
    context = {'data': table}
    return render(request, 'BankingApp/ViewAccRequest.html', context)

def GenerateCNo(request):
    bank = request.session['bank']
    rid = str(request.GET['id'])
    account_number = ''.join(str(random.randint(1, 9)) for _ in range(16))
    con = Database.connect()
    cur = con.cursor()
    cur.execute("update account set cardno='" + str(account_number) + "'where id='" + rid + "'")
    con.commit()
    table = getTableData(bank)
    context = {'data': table}
    return render(request, 'BankingApp/ViewAccRequest.html', context)

def GenerateCVV(request):
    bank = request.session['bank']
    rid = str(request.GET['id'])
    account_number = ''.join(str(random.randint(1, 9)) for _ in range(3))
    con = Database.connect()
    cur = con.cursor()
    cur.execute("select * from bank where bank='"+bank+"'")
    data=cur.fetchone()
    ifsc_code=data[2]

    #generate exp_date
    current_date = datetime.today()
    future_date = current_date.replace(year=current_date.year + 5)
    exp_date=future_date.strftime("%Y-%m-%d")

    cur.execute("update account set cvv='" + str(account_number) + "',ifsc='"+ifsc_code+"',exp_date='"+exp_date+"'where id='" + rid + "'")
    con.commit()
    table = getTableData(bank)
    context = {'data': table}
    return render(request, 'BankingApp/ViewAccRequest.html', context)


def cashhome(request):
    return render(request, 'BankingApp/CashierHome.html')

def CaDepositRequest(request):
    bank=request.session['bank']
    table = "<table><tr>"
    table += "<th>Account No</th>"
    table += "<th>IFSC</th>"
    table += "<th>Customer ID</th>"
    table += "<th>Requested Amount</th>"
    table += "<th>Total Amount</th>"
    table += "<th>Action</th>"
    table += "</tr>"

    con = Database.connect()
    cur = con.cursor()
    cur.execute("select * from account where bank='" + bank + "' and dep_status='Requested'")
    data = cur.fetchall()
    for d in data:
        table += "<tr>"
        table += f"<td>{d[5]}</td>"
        table += f"<td>{d[6]}</td>"
        table += f"<td>{d[1]}</td>"
        table += f"<td>{d[12]}</td>"
        table += f"<td>{d[11]}</td>"
        table += f"<td><a href='AcceptDeposit?id={d[0]}&r_amount={d[12]}&t_amount={d[11]}'>Accept</a></td>"
        table += "</tr>"


    table+="</table>"
    context={'data':table}
    return render(request, 'BankingApp/DepositRequest.html',context)

def AcceptDeposit(request):
    bank = request.session['bank']
    rid=str(request.GET['id'])
    total_amt=float(request.GET['t_amount'])
    r_amount=float(request.GET['r_amount'])

    total_amt=total_amt+r_amount

    con=Database.connect()
    cur=con.cursor()
    cur.execute("update account set amount='"+str(total_amt)+"',req_amount=0,dep_status='waiting' where id='"+rid+"'")
    con.commit()
    table = "<table><tr>"
    table += "<th>Account No</th>"
    table += "<th>IFSC</th>"
    table += "<th>Customer ID</th>"
    table += "<th>Requested Amount</th>"
    table += "<th>Total Amount</th>"
    table += "<th>Action</th>"
    table += "</tr>"

    cur.execute("select * from account where bank='" + bank + "' and dep_status='Requested'")
    data = cur.fetchall()
    for d in data:
        table += "<tr>"
        table += f"<td>{d[5]}</td>"
        table += f"<td>{d[6]}</td>"
        table += f"<td>{d[1]}</td>"
        table += f"<td>{d[12]}</td>"
        table += f"<td>{d[11]}</td>"
        table += f"<td><a href='AcceptDeposit?id={d[0]}&r_amount={d[12]}&t_amount={d[11]}'>Accept</a></td>"
        table += "</tr>"
    table += "</table>"
    context = {'data': table}
    return render(request, 'BankingApp/DepositRequest.html', context)


def CaWithdrawRequest(request):
    bank = request.session['bank']
    table = "<table><tr>"
    table += "<th>Account No</th>"
    table += "<th>IFSC</th>"
    table += "<th>Customer ID</th>"
    table += "<th>Requested Amount</th>"
    table += "<th>Total Amount</th>"
    table += "<th>Action</th>"
    table += "</tr>"

    con = Database.connect()
    cur = con.cursor()
    cur.execute("select * from account where bank='" + bank + "' and with_status='Requested'")
    data = cur.fetchall()
    for d in data:
        table += "<tr>"
        table += f"<td>{d[5]}</td>"
        table += f"<td>{d[6]}</td>"
        table += f"<td>{d[1]}</td>"
        table += f"<td>{d[12]}</td>"
        table += f"<td>{d[11]}</td>"
        table += f"<td><a href='AcceptWithdraw?id={d[0]}&r_amount={d[12]}&t_amount={d[11]}'>Accept</a></td>"
        table += "</tr>"

    table += "</table>"
    context = {'data': table}
    return render(request, 'BankingApp/WithdrawRequest.html', context)

def AcceptWithdraw(request):
    bank = request.session['bank']
    rid = str(request.GET['id'])
    total_amt = float(request.GET['t_amount'])
    r_amount = float(request.GET['r_amount'])

    total_amt = total_amt - r_amount

    con = Database.connect()
    cur = con.cursor()
    cur.execute(
        "update account set amount='" + str(total_amt) + "',req_amount=0,with_status='waiting' where id='" + rid + "'")
    con.commit()
    table = "<table><tr>"
    table += "<th>Account No</th>"
    table += "<th>IFSC</th>"
    table += "<th>Customer ID</th>"
    table += "<th>Requested Amount</th>"
    table += "<th>Total Amount</th>"
    table += "<th>Action</th>"
    table += "</tr>"

    con = Database.connect()
    cur = con.cursor()
    cur.execute("select * from account where bank='" + bank + "' and with_status='Requested'")
    data = cur.fetchall()
    for d in data:
        table += "<tr>"
        table += f"<td>{d[5]}</td>"
        table += f"<td>{d[6]}</td>"
        table += f"<td>{d[1]}</td>"
        table += f"<td>{d[12]}</td>"
        table += f"<td>{d[11]}</td>"
        table += f"<td><a href='AcceptWithdraw?id={d[0]}&r_amount={d[12]}&t_amount={d[11]}'>Accept</a></td>"
        table += "</tr>"

    table += "</table>"
    context = {'data': table}
    return render(request, 'BankingApp/WithdrawRequest.html', context)










def manhome(request):
    return render(request, 'BankingApp/ManagerHome.html')

def MViewEmployees(request):
    bank = request.session['bank']


    con = Database.connect()

    con.commit()
    table = "<table><tr>"
    table += "<th>Bank Name</th>"
    table += "<th>Full Name</th>"
    table += "<th>Email</th>"
    table += "<th>Mobile</th>"
    table += "<th>Address</th>"
    table += "<th>Role</th>"
    table += "</tr>"

    cur = con.cursor()
    cur.execute("select * from employee where bank='"+bank+"' and status!='Manager'")
    data = cur.fetchall()
    for d in data:
        table += "<tr>"
        table += f"<td>{d[1]}</td>"
        table += f"<td>{d[2]}</td>"
        table += f"<td>{d[3]}</td>"
        table += f"<td>{d[4]}</td>"
        table += f"<td>{d[5]}</td>"
        table += f"<td>{d[8]}</td>"
        table += "</tr>"

    table += "</table>"

    context = {'data': table}
    return render(request, 'BankingApp/MViewEmployees.html',context)

def MViewAccRequest(request):
    bank = request.session['bank']

    con = Database.connect()

    con.commit()
    table = "<table><tr>"
    table += "<th>Bank</th>"
    table += "<th>Customer ID</th>"
    table += "<th>Account No</th>"
    table += "<th>Card No</th>"
    table += "<th>Expiry Date</th>"
    table += "</tr>"

    cur = con.cursor()
    cur.execute("select * from account where bank='" + bank + "'")
    data = cur.fetchall()
    for d in data:
        table += "<tr>"
        table += f"<td>{d[2]}</td>"
        table += f"<td>{d[1]}</td>"
        table += f"<td>{d[5]}</td>"
        table += f"<td>{d[7]}</td>"
        table += f"<td>{d[10]}</td>"
        table += "</tr>"

    table += "</table>"

    context = {'data': table}
    return render(request, 'BankingApp/MViewAccounts.html', context)

def MViewAllTransactions(request):
    bank = request.session['bank']

    con = Database.connect()

    table = "<table><tr>"
    table += "<th>Customer ID</th>"
    table += "<th>Bank Name</th>"
    table += "<th>Account No</th>"
    table += "<th>Status</th>"
    table += "<th>Amount</th>"
    table += "<th>Date</th>"

    table += "</tr>"

    cur = con.cursor()
    cur.execute("select * from transactions where bank='" + bank + "'")
    data = cur.fetchall()
    for d in data:
        table += "<tr>"
        table += f"<td>{d[1]}</td>"
        table += f"<td>{d[2]}</td>"
        table += f"<td>{d[3]}</td>"
        table += f"<td>{d[4]}</td>"
        table += f"<td>{d[5]}</td>"
        table += f"<td>{d[6]}</td>"
        table += "</tr>"
    table += "</table>"

    context = {'data': table}
    return render(request, 'BankingApp/MViewAllTransactions.html', context)


