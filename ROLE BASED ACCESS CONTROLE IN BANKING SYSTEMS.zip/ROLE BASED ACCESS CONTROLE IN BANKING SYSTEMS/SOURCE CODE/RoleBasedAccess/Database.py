import pymysql

def connect():
    con=pymysql.connect(host='localhost', user='root', password='root', database='role_based', charset='utf8')
    return con