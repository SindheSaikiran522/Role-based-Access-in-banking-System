from django.urls import path,include
from CustomerApp import views


urlpatterns = [
    path('login', views.login),
    path('Register', views.Register),
    path('RegAction', views.RegAction),
    path('LogAction', views.LogAction),
    path('home', views.home),
    path('AccRequest', views.AccRequest),
    path('RequestAction', views.RequestAction),
    path('AccountStatus', views.AccountStatus),
    path('Transactions', views.Transactions),
    path('Deposit', views.Deposit),
    path('DepositAction', views.DepositAction),
    path('Withdraw', views.Withdraw),
    path('WithdrawAction', views.WithdrawAction),
    path('MyTransactions', views.MyTransactions),

]
