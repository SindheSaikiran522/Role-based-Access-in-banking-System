from django.shortcuts import render
import Database

# Create your views here.
def login(request):
    con=Database.connect()
    cur=con.cursor()
    cur.execute("select * from bank")
    data = cur.fetchall()
    output = ""
    for d in data:
        output += f"<option value={d[1]}>{d[1]}</option>"
    output += ""

    context = {'data': output}
    return render(request, 'CustomerApp/Login.html', context)

def Register(request):
    con = Database.connect()
    cur = con.cursor()
    cur.execute("select * from bank")
    data = cur.fetchall()
    output = ""
    for d in data:
        output += f"<option value={d[1]}>{d[1]}</option>"
    output += ""

    context = {'data': output}
    return render(request, 'CustomerApp/Register.html', context)

def RegAction(request):
    if request.method=='POST':
        bank = request.POST['bank']
        name = request.POST['name']
        email = request.POST['email']
        mobile = request.POST['mobile']
        address = request.POST['address']
        uname = request.POST['username']
        pwd = request.POST['password']

        con = Database.connect()
        cur = con.cursor()
        cur.execute("select * from customer where email='"+email+"' or mobile='"+mobile+"'")
        data=cur.fetchone()
        if data is not None:
            cur.execute("select * from bank")
            data = cur.fetchall()
            output = ""
            for d in data:
                output += f"<option value={d[1]}>{d[1]}</option>"
            output += ""

            context = {'msg': "Email or Mobile Number is Already Exist...!!",'data': output}
            return render(request, 'CustomerApp/Register.html', context)
        else:
            cur.execute("insert into customer values(null,'"+bank+"','"+name+"','"+email+"','"+mobile+"','"+address+"','"+uname+"','"+pwd+"')")
            con.commit()
            cur.execute("select * from bank")
            data = cur.fetchall()
            output = ""
            for d in data:
                output += f"<option value={d[1]}>{d[1]}</option>"
            output += ""

            context = {'msg': "Registration Successful...!!",'data': output}
            return render(request, 'CustomerApp/Register.html', context)

def LogAction(request):
    bank = request.POST['bank']
    uname = request.POST['username']
    pwd = request.POST['password']

    con = Database.connect()
    cur = con.cursor()
    cur.execute("select * from customer where username='" + uname + "' and password='" + pwd + "' and bank='"+bank+"'")
    d=cur.fetchone()
    if d is not None:
        request.session['id']= d[0]
        request.session['bank'] = d[1]
        request.session['name'] = d[2]
        request.session['email'] = d[3]
        request.session['mobile'] = d[4]
        return render(request,'CustomerApp/CustomerHome.html')

    else:
        cur = con.cursor()
        cur.execute("select * from bank")
        data = cur.fetchall()
        output = ""
        for d in data:
            output += f"<option value={d[1]}>{d[1]}</option>"
        output += ""

        context = {'data': output,'msg':'Login Failed...!!'}
        return render(request, 'CustomerApp/Login.html', context)

def home(request):
    return render(request, 'CustomerApp/CustomerHome.html')

def AccRequest(request):
    return render(request, 'CustomerApp/AccountRequest.html')

def RequestAction(request):
    cid=str(request.session['id'])
    bank=request.POST['bank']
    aadhar=request.POST['aadhar']
    pan=request.POST['pan']

    con = Database.connect()
    cur = con.cursor()
    cur.execute("select * from account where cid='" + cid + "' and bank='" + bank + "'")
    data = cur.fetchone()
    if data is not None:
        context = {'msg': "Already Sent Request"}
        return render(request, 'CustomerApp/AccountRequest.html', context)
    else:
        cur.execute(
            "insert into account values(null,'" + cid + "','" + bank + "','" + aadhar + "','" + pan + "','waiting','waiting','waiting','waiting',now(),'waiting','0','0','waiting','0','waiting')")
        con.commit()
        context = {'msg': "Account Request Sent Successful...!!"}
        return render(request, 'CustomerApp/AccountRequest.html', context)

def AccountStatus(request):
    cid = str(request.session['id'])

    con = Database.connect()

    table = "<table><tr>"
    table += "<th>Bank Name</th>"
    table += "<th>Account No</th>"
    table += "<th>IFSC Code</th>"
    table += "<th>Card No</th>"
    table += "<th>CVV</th>"
    table += "<th>Total Available Amount</th>"
    table += "<th>Expiry Date</th>"
    table += "</tr>"

    cur = con.cursor()
    cur.execute("select * from account where cid='"+cid+"'")
    data = cur.fetchall()
    for d in data:
        table += "<tr>"
        table += f"<td>{d[2]}</td>"
        table += f"<td>{d[5]}</td>"
        table += f"<td>{d[6]}</td>"
        table += f"<td>{d[7]}</td>"
        table += f"<td>{d[8]}</td>"
        table += f"<td>{d[11]}</td>"
        table += f"<td>{d[10]}</td>"
        table += "</tr>"
    table += "</table>"

    context = {'data': table}
    return render(request, 'CustomerApp/ViewAccountStatus.html', context)

def Transactions(request):
    return render(request, 'CustomerApp/Transactions.html')

def Deposit(request):
    return render(request, 'CustomerApp/Deposit.html')

def DepositAction(request):
    cid=str(request.session['id'])
    bank=request.POST['bank']
    acc = request.POST['acc']
    amount = request.POST['amount']

    con=Database.connect()
    cur=con.cursor()
    cur.execute("select * from account where cid='"+cid+"'and bank='"+bank+"'and acc_no='"+acc+"'")
    da=cur.fetchone()
    if da is not None:
        cur.execute("update account set req_amount='"+amount+"',dep_status='Requested' where cid='"+cid+"'and bank='"+bank+"'and acc_no='"+acc+"'")
        con.commit()
        cur.execute(
            "insert into transactions values(null,'" + cid + "','" + bank + "','" + acc + "','deposit','" + amount + "',now())")
        con.commit()
        context = {'msg': 'Deposit Request Sent to Cashier...!!'}
        return render(request, 'CustomerApp/Deposit.html', context)
    else:
        context={'msg':'Please Enter Valid Details...!!'}
        return render(request, 'CustomerApp/Deposit.html',context)


def Withdraw(request):
    return render(request, 'CustomerApp/Withdraw.html')

def WithdrawAction(request):
    cid = str(request.session['id'])
    bank = request.POST['bank']
    acc = request.POST['acc']
    amount = request.POST['amount']

    con = Database.connect()
    cur = con.cursor()
    cur.execute("select * from account where cid='" + cid + "'and bank='" + bank + "'and acc_no='" + acc + "'")
    da = cur.fetchone()
    if da is not None:
        cur.execute(
            "update account set req_amount='" + amount + "',with_status='Requested' where cid='" + cid + "'and bank='" + bank + "'and acc_no='" + acc + "'")
        con.commit()
        cur.execute("insert into transactions values(null,'"+cid+"','"+bank+"','"+acc+"','withdraw','"+amount+"',now())")
        con.commit()
        context = {'msg': 'Withdraw Request Sent to Cashier...!!'}
        return render(request, 'CustomerApp/Withdraw.html', context)
    else:
        context = {'msg': 'Please Enter Valid Details...!!'}
        return render(request, 'CustomerApp/Withdraw.html', context)


def MyTransactions(request):
    cid = str(request.session['id'])

    con = Database.connect()

    table = "<table><tr>"
    table += "<th>Bank Name</th>"
    table += "<th>Account No</th>"
    table += "<th>Status</th>"
    table += "<th>Amount</th>"
    table += "<th>Date</th>"

    table += "</tr>"

    cur = con.cursor()
    cur.execute("select * from transactions where cid='" + cid + "'")
    data = cur.fetchall()
    for d in data:
        table += "<tr>"
        table += f"<td>{d[2]}</td>"
        table += f"<td>{d[3]}</td>"
        table += f"<td>{d[4]}</td>"
        table += f"<td>{d[5]}</td>"
        table += f"<td>{d[6]}</td>"
        table += "</tr>"
    table += "</table>"

    context = {'data': table}
    return render(request, 'CustomerApp/ViewTransactions.html', context)