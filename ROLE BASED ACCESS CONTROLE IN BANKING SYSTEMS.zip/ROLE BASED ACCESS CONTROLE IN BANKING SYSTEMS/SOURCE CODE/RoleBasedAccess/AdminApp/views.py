from django.shortcuts import render
import Database

# Create your views here.
def index(request):
    return render(request,'index.html')

def login(request):
    return render(request,'AdminApp/Login.html')

def LogAction(request):
    if request.method=='POST':
        uname=request.POST['username']
        pwd=request.POST['password']

        if uname == 'Admin' and pwd == 'Admin':
            return render(request,'AdminApp/AdminHome.html')
        else:
            context={'msg':'Login Failed..!!'}
            return render(request,'AdminApp/Login.html', context)


def AddBank(request):
    return render(request,'AdminApp/AddBank.html')

def AddBankAction(request):
    bank=request.POST['bank']
    ifsc=request.POST['ifsc']
    con=Database.connect()
    cur=con.cursor()
    cur.execute("select count(*) from bank where bank='"+bank+"' and ifsc='"+ifsc+"'")
    d=cur.fetchone()
    print(d)
    if int(d[0]) >0:
        context={'msg':'Bank Name Already Exist...!!'}
        return render(request,'AdminApp/AddBank.html',context)
    else:
        cur.execute("insert into bank values(null,'"+bank+"','"+ifsc+"')")
        con.commit()
        context = {'msg': 'Bank Name Added Successfully...!!'}
        return render(request, 'AdminApp/AddBank.html', context)


def ViewEmployees(request):
    table="<table><tr>"
    table+="<th>Bank Name</th>"
    table += "<th>Full Name</th>"
    table += "<th>Email</th>"
    table += "<th>Mobile</th>"
    table += "<th>Address</th>"
    table += "<th>Role Status</th>"
    table += "<th>Assign Role</th>"
    table += "</tr>"

    con = Database.connect()
    cur = con.cursor()
    cur.execute("select * from employee")
    data = cur.fetchall()
    for d in data:
        status=d[8]
        if status=='waiting':
            table+="<tr>"
            table+=f"<td>{d[1]}</td>"
            table += f"<td>{d[2]}</td>"
            table += f"<td>{d[3]}</td>"
            table += f"<td>{d[4]}</td>"
            table += f"<td>{d[5]}</td>"
            table += f"<td>{d[8]}</td>"
            table += f"<td><a href='AssignRole?id={d[0]}'>Assign</a></td>"
            table +="</tr>"
        else:
            table += "<tr>"
            table += f"<td>{d[1]}</td>"
            table += f"<td>{d[2]}</td>"
            table += f"<td>{d[3]}</td>"
            table += f"<td>{d[4]}</td>"
            table += f"<td>{d[5]}</td>"
            table += f"<td>{d[8]}</td>"
            table += f"<td>Assigned</td>"
            table += "</tr>"

    table +="</table>"

    context = {'data': table}
    return render(request, 'AdminApp/ViewEmployees.html', context)

def AssignRole(request):
    id=request.GET['id']
    context = {'id': id}
    return render(request, 'AdminApp/AssignRole.html', context)

def AddRoleAction(request):
    emp_id=request.POST['emp_id']
    role = request.POST['role']
    con = Database.connect()
    cur = con.cursor()
    cur.execute("update employee set status='"+role+"' where id='"+emp_id+"'")
    con.commit()
    table = "<table><tr>"
    table += "<th>Bank Name</th>"
    table += "<th>Full Name</th>"
    table += "<th>Email</th>"
    table += "<th>Mobile</th>"
    table += "<th>Address</th>"
    table += "<th>Role Status</th>"
    table += "<th>Assign Role</th>"
    table += "</tr>"


    cur = con.cursor()
    cur.execute("select * from employee")
    data = cur.fetchall()
    for d in data:
        status = d[8]
        if status == 'waiting':
            table += "<tr>"
            table += f"<td>{d[1]}</td>"
            table += f"<td>{d[2]}</td>"
            table += f"<td>{d[3]}</td>"
            table += f"<td>{d[4]}</td>"
            table += f"<td>{d[5]}</td>"
            table += f"<td>{d[8]}</td>"
            table += f"<td><a href='AssignRole?id={d[0]}'>Assign</a></td>"
            table += "</tr>"
        else:
            table += "<tr>"
            table += f"<td>{d[1]}</td>"
            table += f"<td>{d[2]}</td>"
            table += f"<td>{d[3]}</td>"
            table += f"<td>{d[4]}</td>"
            table += f"<td>{d[5]}</td>"
            table += f"<td>{d[8]}</td>"
            table += f"<td>Assigned</td>"
            table += "</tr>"

    table += "</table>"

    context = {'data': table}
    return render(request, 'AdminApp/ViewEmployees.html', context)

def ViewCustomers(request):
    table = "<table><tr>"
    table += "<th>Bank Name</th>"
    table += "<th>Full Name</th>"
    table += "<th>Email</th>"
    table += "<th>Mobile</th>"
    table += "<th>Address</th>"
    table += "</tr>"

    con = Database.connect()
    cur = con.cursor()
    cur.execute("select * from customer")
    data = cur.fetchall()
    for d in data:

        table += "<tr>"
        table += f"<td>{d[1]}</td>"
        table += f"<td>{d[2]}</td>"
        table += f"<td>{d[3]}</td>"
        table += f"<td>{d[4]}</td>"
        table += f"<td>{d[5]}</td>"
        table += "</tr>"

    table += "</table>"

    context = {'data': table}
    return render(request, 'AdminApp/ViewCustomers.html', context)

