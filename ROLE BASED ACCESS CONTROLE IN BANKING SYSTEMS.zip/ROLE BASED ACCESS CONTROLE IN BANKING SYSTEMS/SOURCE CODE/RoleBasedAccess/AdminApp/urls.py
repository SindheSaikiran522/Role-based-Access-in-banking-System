from django.urls import path,include
from AdminApp import views


urlpatterns = [
    path('', views.index),
    path('login', views.login),
    path('LogAction', views.LogAction),
    path('AddBank', views.AddBank),
    path('AddBankAction', views.AddBankAction),
    path('ViewEmployees', views.ViewEmployees),
    path('AssignRole', views.AssignRole),
    path('AddRoleAction', views.AddRoleAction),
    path('ViewCustomers', views.ViewCustomers),

]
